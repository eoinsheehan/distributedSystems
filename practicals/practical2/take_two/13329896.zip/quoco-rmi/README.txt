To run the docker images run the following in the root folder called quoco-rmi:
- docker-compose build
- docker-compose up --force-recreate

